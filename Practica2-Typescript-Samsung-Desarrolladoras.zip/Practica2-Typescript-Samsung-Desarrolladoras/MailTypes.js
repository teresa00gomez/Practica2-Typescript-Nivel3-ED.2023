"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MailTypes = void 0;
var MailTypes;
(function (MailTypes) {
    MailTypes["PERSONAL"] = "Personal";
    MailTypes["WORK"] = "work";
})(MailTypes = exports.MailTypes || (exports.MailTypes = {}));
