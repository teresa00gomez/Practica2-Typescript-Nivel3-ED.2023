export enum MailTypes{
    PERSONAL = "Personal",
    WORK = "work"
}