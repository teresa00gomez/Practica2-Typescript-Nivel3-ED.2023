"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PhoneTypes = void 0;
var PhoneTypes;
(function (PhoneTypes) {
    PhoneTypes["WORK"] = "Work";
    PhoneTypes["PERSONAL"] = "Personal";
    PhoneTypes["HOME"] = "Home";
})(PhoneTypes = exports.PhoneTypes || (exports.PhoneTypes = {}));
