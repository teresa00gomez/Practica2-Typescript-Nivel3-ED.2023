export enum PhoneTypes {
    WORK = "Work",
    PERSONAL = "Personal",
    HOME = "Home"
}